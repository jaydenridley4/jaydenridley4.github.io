//
//  DeltaCore.m
//  DeltaCore
//
//  Created by Riley Testut on 6/30/16.
//  Copyright © 2016 Riley Testut. All rights reserved.
//

@import Foundation;

NSNotificationName const DeltaRegistrationRequestNotification = @"DeltaRegistrationRequestNotification";
