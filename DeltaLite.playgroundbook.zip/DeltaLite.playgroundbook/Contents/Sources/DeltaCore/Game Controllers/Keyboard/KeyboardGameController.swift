//
//  KeyboardGameController.swift
//  DeltaCore
//
//  Created by Riley Testut on 6/14/18.
//  Copyright © 2018 Riley Testut. All rights reserved.
//

import UIKit

public extension GameControllerInputType
{
    static let keyboard = GameControllerInputType("keyboard")
}

public struct KeyboardGameControllerInput: Hashable, RawRepresentable, Codable
{
    public let rawValue: String
    
    public init(rawValue: String)
    {
        self.rawValue = rawValue
    }
    
    public init(_ rawValue: String)
    {
        self.rawValue = rawValue
    }
}

extension KeyboardGameControllerInput: Input
{
    public var type: InputType {
        return .controller(.keyboard)
    }
    
    public init(stringValue: String)
    {
        self.init(rawValue: stringValue)
    }
}

public extension KeyboardGameControllerInput
{
    static let up = KeyboardGameControllerInput("up")
    static let down = KeyboardGameControllerInput("down")
    static let left = KeyboardGameControllerInput("left")
    static let right = KeyboardGameControllerInput("right")
    
    static let escape = KeyboardGameControllerInput("escape")
    
    static let shift = KeyboardGameControllerInput("shift")
    static let command = KeyboardGameControllerInput("command")
    static let option = KeyboardGameControllerInput("option")
    static let control = KeyboardGameControllerInput("control")
    static let capsLock = KeyboardGameControllerInput("capsLock")
    
    static let space = KeyboardGameControllerInput("space")
    static let `return` = KeyboardGameControllerInput("return")
    static let tab = KeyboardGameControllerInput("tab")
}

public class KeyboardGameController: UIResponder, GameController
{
    public var name: String {
        return NSLocalizedString("Keyboard", comment: "")
    }
    
    public var playerIndex: Int?
    
    public let inputType: GameControllerInputType = .keyboard
    
    public private(set) lazy var defaultInputMapping: GameControllerInputMappingProtocol? = {
        guard let fileURL = Bundle(for: KeyboardGameController.self).url(forResource: "KeyboardGameController", withExtension: "deltamapping") else {
            fatalError("KeyboardGameController.deltamapping does not exist.")
        }
        
        do
        {
            let inputMapping = try GameControllerInputMapping(fileURL: fileURL)
            return inputMapping
        }
        catch
        {
            print(error)
            
            fatalError("KeyboardGameController.deltamapping does not exist.")
        }
    }()
}

public extension KeyboardGameController
{
    override func keyPressesBegan(_ presses: Set<KeyPress>, with event: UIEvent)
    {
        for press in presses
        {
            let input = KeyboardGameControllerInput(press.key)
            self.activate(input)
        }
    }
    
    override func keyPressesEnded(_ presses: Set<KeyPress>, with event: UIEvent)
    {
        for press in presses
        {
            let input = KeyboardGameControllerInput(press.key)
            self.deactivate(input)
        }
    }
}
