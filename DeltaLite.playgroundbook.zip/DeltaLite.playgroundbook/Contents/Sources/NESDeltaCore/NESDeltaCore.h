//
//  NESDeltaCore.h
//  NESDeltaCore
//
//  Created by Riley Testut on 2/25/18.
//  Copyright © 2018 Riley Testut. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NESDeltaCore.
FOUNDATION_EXPORT double NESDeltaCoreVersionNumber;

//! Project version string for NESDeltaCore.
FOUNDATION_EXPORT const unsigned char NESDeltaCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NESDeltaCore/PublicHeader.h>
#import <NESDeltaCore/NESEmulatorBridge.hpp>

